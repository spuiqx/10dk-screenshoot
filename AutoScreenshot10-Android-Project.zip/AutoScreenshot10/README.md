# SPUIQX Auto Screenshot — Android proje

## Android 16 telefondan APK oluşturmanın kolay yolu (GitHub Actions)

Bu proje kaynak koddur. APK, GitHub'ın bulut derleme sistemiyle oluşturulabilir; bilgisayara ihtiyaç yoktur.

1. Telefonda tarayıcıdan https://github.com adresini açıp ücretsiz hesap oluştur veya giriş yap.
2. **New repository** ile yeni bir repository oluştur. Örneğin `AutoScreenshot10`; Public veya Private seçebilirsin.
3. Bu ZIP'i telefonda çıkart. GitHub repository sayfasında **Add file > Upload files** ile ZIP'in içindeki tüm dosya ve klasörleri yükle. `.github` klasörünün de yüklendiğinden emin ol. (GitHub web arayüzü gizli klasörleri göstermiyorsa GitHub mobil tarayıcıda masaüstü görünümünü aç.)
4. **Commit changes** ile dosyaları kaydet.
5. Repository'de **Actions** sekmesine gir. `Build Android APK` iş akışı çalışır; çalışmazsa **Run workflow** seç.
6. İşlem bitince başarılı çalışmaya gir, **Artifacts** bölümündeki `AutoScreenshot10-debug-apk` dosyasını indir.
7. İndirilen ZIP'i aç. İçindeki `app-debug.apk` dosyasına dokun ve Android'in istediği “Bu kaynaktan yüklemeye izin ver” iznini vererek kur.

## Uygulama kullanımı

Uygulamayı açıp BAŞLAT'a dokun. Android'in ekran yakalama iznini onayla. Yakalama devam ederken kalıcı bildirim görünür. DURDUR ile durdurabilirsin. Ekran görüntüleri Galeri > Pictures > AutoScreenshots konumuna kaydedilir.

## Önemli

- Android, ekran yakalama iznini sistem penceresiyle kullanıcıdan ister; gizli yakalama yapılmaz.
- Servis açık ve izin geçerliyken 10 dakikada bir, ekrandaki son kareyi kaydetmeye çalışır.
- Android/üretici pil yönetimi arka plan servisini durdurabilir. Telefon yeniden başlatılırsa tekrar başlatıp izin vermen gerekir.
- Bu paket imzalı mağaza sürümü değil, test amaçlı debug APK üretir.
