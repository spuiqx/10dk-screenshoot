plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.spuiqx.autoscreenshot"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.spuiqx.autoscreenshot"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
    implementation("androidx.activity:activity-ktx:1.9.3")
}
